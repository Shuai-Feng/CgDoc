export default {
  nameSpace: 'Login',
  state: {},
  reducers: {},
};
