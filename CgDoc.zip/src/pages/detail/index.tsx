import * as React from 'react';
import { Form,Input,Card,Button} from 'antd';

interface IDetialProps {
}

const Detial: React.FunctionComponent<IDetialProps> = (props) => {

  return <div>
    <Card>
        detail
    </Card>
  </div> ;
};

export default Detial;
