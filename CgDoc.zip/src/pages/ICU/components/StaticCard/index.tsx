import * as React from 'react';
import style from './style.less';

//
export type CardData = {
  title: string | React.ReactNode;
  subTitle?: string | number;
  content?: string | React.ReactNode;
};

interface IStaticCardProps {
  staticData: CardData[];
}

const StaticCard: React.FunctionComponent<IStaticCardProps> = props => {
  return (
    <div className={style.CardWrapper}>
      {props.staticData.map(item => {
        const { title, titleValue } = item;
        return <div className={style.CardItem}>
          <p>{title}</p>
          <p>{title}</p>
        </div>;
      })}
    </div>
  );
};

export default StaticCard;
