import React, { useEffect } from 'react';
import axios from 'axios';
import { useRequest } from 'ahooks';
import DynamicAntdTheme from 'dynamic-antd-theme';
// 给组件引进来
import StaticCard, { CardData } from './components/StaticCard';

interface IICUpageProps {}

const ICUpage: React.FunctionComponent<IICUpageProps> = props => {
  function getUsername(): Promise<string> {
    return new Promise(resolve => {
      axios.get('https://randomuser.me/api').then(res => {
        resolve(res.data.results[0].phone);
      });
    });
  }
  useEffect(() => {
    axios.get('https://randomuser.me/api').then(res => {
      console.log(res.data.results[0].phone);
    });
  }, []);
  const { data, loading, run, cancel } = useRequest(getUsername, {
    pollingInterval: 1000,
    pollingWhenHidden: false,
  });



  return (
    <div className="ICU_page">
        <DynamicAntdTheme/>
    </div>
  );
};

export default ICUpage;
