// @ts-nocheck
import React from 'react';
import { ApplyPluginsType, dynamic } from 'D:/xampp/htdocs/CgDoc/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';
import LoadingComponent from '@/component/Loading';

export function getRoutes() {
  const routes = [
  {
    "exact": false,
    "path": "/",
    "component": dynamic({ loader: () => import(/* webpackChunkName: 'layouts__index' */'@/layouts/index.tsx'), loading: LoadingComponent}),
    "routes": [
      {
        "exact": true,
        "path": "/login",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__login' */'@/pages/login'), loading: LoadingComponent})
      },
      {
        "exact": true,
        "path": "/",
        "redirect": "/home"
      },
      {
        "exact": true,
        "path": "/home",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__home' */'@/pages/home'), loading: LoadingComponent})
      },
      {
        "path": "/user",
        "routes": [
          {
            "exact": true,
            "path": "/user/userDelete",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__user__userDelete' */'@/pages/user/userDelete'), loading: LoadingComponent})
          },
          {
            "exact": true,
            "path": "/user/userAdd",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__user__userAdd' */'@/pages/user/userAdd'), loading: LoadingComponent})
          }
        ]
      },
      {
        "exact": true,
        "path": "/medic",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__medic' */'@/pages/medic'), loading: LoadingComponent})
      },
      {
        "exact": true,
        "path": "/monitor",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__monitor' */'@/pages/monitor'), loading: LoadingComponent})
      },
      {
        "exact": true,
        "path": "/order",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__order' */'@/pages/order'), loading: LoadingComponent})
      },
      {
        "exact": true,
        "path": "/doctor",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__doctor' */'@/pages/doctor'), loading: LoadingComponent})
      },
      {
        "exact": true,
        "path": "/detail",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__detail' */'@/pages/detail'), loading: LoadingComponent})
      },
      {
        "exact": true,
        "path": "/ICU",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__ICU' */'@/pages/ICU'), loading: LoadingComponent})
      },
      {
        "exact": true,
        "path": "/demo1",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__demo1' */'@/pages/demo1'), loading: LoadingComponent})
      },
      {
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404page' */'@/pages/404page'), loading: LoadingComponent}),
        "exact": true
      }
    ]
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
