<?php
    echo '123';
?>